<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="<?php echo base_url('bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
  </head>
  <body>

    <div class="container mt-4">
      <h1 >Hello, world!</h1>
      <p class="">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure, fugiat numquam dicta est voluptate accusantium possimus exercitationem quo a unde temporibus veritatis id. Veritatis harum, qui maiores error repudiandae ratione quisquam aliquam repellendus facilis quia explicabo totam quidem voluptatem! Veniam nemo culpa officiis, ullam saepe rem ipsam mollitia accusantium. Odit placeat cumque in voluptatem voluptatum fuga quidem, tempora corporis harum numquam! Provident libero consequuntur itaque officiis similique deleniti vitae facere perferendis atque, rerum harum optio voluptate nisi error.</p>
      <button class="btn btn-danger btn-lg ">Ini sudah nyambung ya jangan tanya</button>
    </div>

    <script src="<?php echo base_url('bootstrap/js/bootstrap.bundle.min.js') ?>" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>
